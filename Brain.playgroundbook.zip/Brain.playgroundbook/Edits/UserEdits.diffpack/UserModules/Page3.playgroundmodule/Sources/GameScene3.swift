import SpriteKit

open class GameScene3: SKScene, SKPhysicsContactDelegate {
    
    var brain:SKSpriteNode!
    var gameOver = false
    var movingBrain = false
    var offset: CGPoint!
    var background = SKSpriteNode(imageNamed: "backgroundPage3")
    var gameOverNode = SKSpriteNode(imageNamed: "gameOver0")
    
    // Physics Bit Mask
    let brainCategory    : UInt32 = 0x1 << 0
    let goodIdeaCategory : UInt32 = 0x1 << 1
    let badIdeaCategory  : UInt32 = 0x1 << 2
    let bottomCategory   : UInt32 = 0x1 << 3
    let topCategory      : UInt32 = 0x1 << 4
    
    // Score 
    let highScoreLabel =  SKLabelNode(text: "High Score: \(Score.shared.highScore)")
    let scoreLabel = SKLabelNode(text: "Score: \(Score.shared.amount)")
    var score: Int = 0
    
    // Sound 
    let positiveSoundEffect = SKAction.playSoundFileNamed("yay.mp3", waitForCompletion: false)
    let negativeSoundEffect = SKAction.playSoundFileNamed("nay.mp3", waitForCompletion: false)
    
    let numRepetitions = 60
    let waitDuration = 0.5
    
    open override func sceneDidLoad(){
        self.backgroundColor = #colorLiteral(red: 0.9754298329, green: 0.8262577653, blue: 0.8796556592, alpha: 1.0)
    }
    
    open override func didMove(to view: SKView) {
        self.size = view.frame.size
        self.physicsWorld.contactDelegate = self
        
        addFonts()
        
        // Add background
        background.zPosition = 0
        background.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
        addChild(background)
        
        // Add player
        addBrain()
        
        addGameOverNode()
        
        // Avoids the player to go off screen
        addMargins()
        
        // Score Labels
        setupLabels()
        
        // Generate rewards during a specific time interval
        let game = SKAction.run(runGame)
        let updateGame = SKAction.run(updateGameOverImage)
        let gameOver = SKAction.run(endGame)
        let gameSequence = SKAction.sequence([game, SKAction.wait(forDuration: Double(numRepetitions) * waitDuration + 2), updateGame, gameOver])
        run(gameSequence)
        
    }
    
    // Player movement
    open override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !gameOver else { return }
        guard let touch = touches.first else { return }
        let touchLocation = touch.location(in: self)
        let touchedNodes = nodes(at:touchLocation)
        
        for node in touchedNodes {
            if node == brain {
                movingBrain = true
                offset = CGPoint(x: touchLocation.x - brain.position.x, y: touchLocation.y - brain.position.y)
            }
        }
    }
    
    open override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !gameOver && movingBrain else { return }
        guard let touch = touches.first else { return }
        let touchLocation = touch.location(in:self)
        var positionY:CGFloat = touchLocation.y - offset.y
        if (positionY > size.height){
            positionY = size.height - brain.frame.height
        }
        if (positionY < 0){
            positionY = frame.minY + brain.frame.height
        }
        let newBrainPosition = CGPoint(x:brain.frame.width * 1.1, y: positionY)
        brain.run(SKAction.move(to:newBrainPosition, duration: 0.01))
    }
    
    open override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        movingBrain = false
    }
    
    // Collisions 
    open func didBegin(_ contact: SKPhysicsContact) {
        if contact.bodyA.categoryBitMask == goodIdeaCategory {
            contact.bodyA.node?.removeFromParent()
            Score.shared.increaseScore()
            //score += 1
            Score.shared.trySavingHighScore()
            updateScoreLabels()
            run(positiveSoundEffect)
        } else if contact.bodyB.categoryBitMask == goodIdeaCategory {
            contact.bodyB.node?.removeFromParent()
            Score.shared.increaseScore()
            //score += 1
            Score.shared.trySavingHighScore()
            updateScoreLabels()
            run(positiveSoundEffect)
        } else if contact.bodyA.categoryBitMask == badIdeaCategory {
            contact.bodyA.node?.removeFromParent()
            Score.shared.decreaseScore()
            //score -= 1
            Score.shared.trySavingHighScore()
            updateScoreLabels()
            run(negativeSoundEffect)
        } else if contact.bodyB.categoryBitMask == badIdeaCategory  {
            contact.bodyB.node?.removeFromParent()
            Score.shared.decreaseScore()
            //score -= 1
            Score.shared.trySavingHighScore()
            updateScoreLabels()
            run(negativeSoundEffect)
        }
    }
    
    // Auxiliary functions
    open func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    
    open func random(min: CGFloat, max: CGFloat) -> CGFloat {
        return random() * (max - min) + min
    }
    
    // Player Sprite
    open func addBrain(){
        let brainTexture = SKTexture(imageNamed: "brain")
        brain = SKSpriteNode(texture: brainTexture, color: .clear, size: CGSize(width: size.width * 0.15, height: size.height * 0.08))
        brain.name = "brain"
        brain.setScale(0.9)
        brain.position = CGPoint(x: brain.frame.width * 1.1, y: frame.midY)
        
        // Physics
        brain.physicsBody = SKPhysicsBody(rectangleOf: brain.frame.size)
        brain.physicsBody?.allowsRotation = false
        brain.physicsBody?.affectedByGravity = false
        brain.physicsBody?.categoryBitMask =  brainCategory
        brain.physicsBody?.contactTestBitMask = goodIdeaCategory
        brain.physicsBody?.collisionBitMask = bottomCategory | topCategory
        self.addChild(brain)
    }
    
    // Rewards 
    open func generateReward(textureName: String, nodeName: String, categoryBitMask: UInt32) {
        let nodeTexture = SKTexture(imageNamed: textureName)
        let node = SKSpriteNode(texture: nodeTexture)
        node.name = nodeName
        node.setScale(0.20)
        node.position = CGPoint(x: frame.size.width + node.size.width/2, y: frame.size.height * random(min: 0, max: 1))
        addChild(node)
        node.run(SKAction.moveBy(x: -frame.size.width - node.size.width, y: 0.0, duration: TimeInterval(random(min: 1.5, max: 2))))
        
        // Physics
        node.physicsBody = SKPhysicsBody(rectangleOf: node.frame.size, center: CGPoint(x: node.size.width/2, y: node.size.height/2))
        node.physicsBody?.isDynamic = false
        node.physicsBody?.affectedByGravity = false
        node.physicsBody?.allowsRotation = false
        node.physicsBody?.categoryBitMask =  categoryBitMask
        node.physicsBody?.contactTestBitMask = brainCategory
    }
    
    open func generateRewardFromType(){
        generateReward(textureName: "idea", nodeName: "goodIdea", categoryBitMask: goodIdeaCategory)
        generateReward(textureName: "badIdea", nodeName: "badIdea", categoryBitMask: badIdeaCategory)
    }
    
    // Score Labels
    open func setupLabels() {
        //High Score
        highScoreLabel.position = CGPoint(x: frame.midX, y:  frame.maxY * 0.90)
        highScoreLabel.fontColor = UIColor.black
        highScoreLabel.fontName = "Apercu-Regular"
        highScoreLabel.fontSize = 40
        highScoreLabel.zPosition = 3
        addChild(highScoreLabel)
        
        //Score
        scoreLabel.position = CGPoint(x: frame.midX, y: frame.maxY * 0.94)
        scoreLabel.fontColor = UIColor.black
        scoreLabel.fontName = "Apercu-Regular"
        scoreLabel.fontSize = 40
        scoreLabel.zPosition = 3
        addChild(scoreLabel)
    }
    
    open func updateScoreLabels(){
        self.scoreLabel.text = "Score: \(Score.shared.amount)"
        self.score = Score.shared.amount
        self.highScoreLabel.text = "High score: \(Score.shared.highScore)"
    }
    
    open func addMargins(){
        let bottomRect = CGRect(x: frame.origin.x, y: frame.minY-1, width: frame.size.width, height: brain.size.height)
        let bottom = SKNode()
        bottom.physicsBody = SKPhysicsBody(edgeLoopFrom: bottomRect)
        bottom.physicsBody!.categoryBitMask = bottomCategory
        bottom.physicsBody?.collisionBitMask = brainCategory
        addChild(bottom)
        
        let topRect = CGRect(x: frame.origin.x, y: frame.maxY-1, width: frame.size.width, height: brain.size.height)
        let top = SKNode()
        bottom.physicsBody = SKPhysicsBody(edgeLoopFrom: topRect)
        bottom.physicsBody!.categoryBitMask = topCategory
        bottom.physicsBody?.collisionBitMask = brainCategory
        addChild(top)
        
    }
    
    open func addFonts(){
        // Adds font for title
        let titleFont = Bundle.main.url(forResource: "ApercuRegular", withExtension: "ttf")! as CFURL
        CTFontManagerRegisterFontsForURL(titleFont, CTFontManagerScope.process, nil)
    }
    
    open func runGame(){
        // Generate rewards during a specific time interval
        let generateRewards = SKAction.run(generateRewardFromType)
        let wait = SKAction.wait(forDuration: waitDuration)
        let sequence = SKAction.sequence([generateRewards, wait])
        let repeatedSequence = SKAction.repeat(sequence, count: numRepetitions)
        run(repeatedSequence)
    }
    
    open func addGameOverNode(){
        gameOverNode.setScale(0.7)
        gameOverNode.position = CGPoint(x: frame.midX, y: frame.midY)
        gameOverNode.isHidden = true
        addChild(gameOverNode)
    }
    
    open func updateGameOverImage(){
        if (score < -3) {
            gameOverNode.texture = SKTexture(imageNamed:"gameOver0")
        } else if (score > 10){
            gameOverNode.texture = SKTexture(imageNamed:"gameOver2")
        } else {
            gameOverNode.texture = SKTexture(imageNamed:"gameOver1")
        }
    }
    
    open func endGame() {
        gameOverNode.isHidden = false
        let scaleUpAction = SKAction.scale(to: 0.8, duration: 0.3)
        gameOverNode.run(scaleUpAction)
        brain.removeFromParent()
    }
}




