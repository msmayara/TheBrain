import Foundation

open class Score {
    public static var shared = Score()
    
    public var amount:Int = 0
    
    open var highScore:Int {
        get{
            return UserDefaults.standard.integer(forKey: "highScore")
        }
        set {
            UserDefaults.standard.set(newValue, forKey: "highScore")
        }
    }
    
    open func increaseScore() {
        self.amount += 1
    }
    
    open func decreaseScore() {
        self.amount -= 1
    }
    
    open func trySavingHighScore(){
        if (self.highScore < self.amount){
            self.highScore = self.amount
        }
    }
}

