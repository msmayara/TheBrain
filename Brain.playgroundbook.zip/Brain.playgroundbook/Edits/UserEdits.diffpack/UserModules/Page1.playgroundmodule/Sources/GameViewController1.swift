import UIKit
import SpriteKit
import AVFoundation

open class GameViewController1: UIViewController{
    var backgroundMusicPlayer: AVAudioPlayer!
    
    open override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        MusicPlayer.shared.startBackgroundMusic(backgroundMusicFileName: "Daystar - Lemon Cake")
    }
    
    open func setup(){
        let view = SKView(frame: CGRect(x: 0, y: 0, width: 1310 , height: 1564))
        let scene = GameScene1()
        scene.scaleMode = .aspectFill
        scene.size = view.bounds.size
        view.presentScene(scene)
        self.view = view
    }
}

