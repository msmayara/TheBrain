import SpriteKit

open class GameScene1: SKScene {
    
    open var background = SKSpriteNode(imageNamed: "backgroundPage1")
    open var myelinNeuron: SKSpriteNode!
    open var noMyelinNeuron: SKSpriteNode!
    var myelin = true
    
    // Sound 
    let clickSoundEffect = SKAction.playSoundFileNamed("click.mp3", waitForCompletion: false)
    
    open override func didMove(to view: SKView) {
        self.size = view.frame.size
        
        // Add background
        background.zPosition = 0
        background.position = CGPoint(x: frame.size.width / 2, y: frame.size.height/2)
        addChild(background)
        
        // Add neurons
        addNeurons()
        
        var myelinNeuronTextures = createTexture("myelin", 15)
        var noMyelinNeuronTextures = createTexture("noMyelin", 21)
                
        animateNode(myelinNeuron, myelinNeuronTextures)
        animateNode(noMyelinNeuron, noMyelinNeuronTextures)
        noMyelinNeuron.isHidden = true
        
        //Add Button
        addAmy()
    }
    
    open func addNeurons(){
        myelinNeuron = SKSpriteNode(texture: SKTexture(imageNamed: "myelin"))
        myelinNeuron.name = "myelinNeuron"
        myelinNeuron.position = CGPoint(x: frame.midX, y:  frame.midY * 1.2)
        addChild(myelinNeuron)
        
        noMyelinNeuron = SKSpriteNode(texture: SKTexture(imageNamed: "noMyelin"))
        noMyelinNeuron.name = "noMyelinNeuron"
        noMyelinNeuron.position = CGPoint(x: frame.midX, y:  frame.midY * 1.2)
        addChild(noMyelinNeuron)
        
    }
    
    open func addNeuron(_ node: SKSpriteNode, _ name: String){
        node.texture = SKTexture(imageNamed: name)
        node.position = CGPoint(x: frame.midX, y: frame.midY*1.2)
        addChild(node)
    }
    
    open func addAmy(){
        let amy = SKSpriteNode(imageNamed: "impulse")
        amy.name = "amy"
        amy.position = CGPoint(x: frame.midX, y:  frame.midY*0.3)
        addChild(amy)
    }
    
    //Create an array of textures to use in animations
    open func createTexture(_ name: String, _ numberImages:Int) -> [SKTexture]{
        var textures:[SKTexture] = []
        for i in 1...numberImages {
            textures.append(SKTexture(imageNamed: name+"\(i)"))
        }
        return textures
    }
    
    open func animateNode(_ node: SKSpriteNode, _ textures: [SKTexture]){
        var animation: SKAction
        animation = SKAction.animate(with: textures, timePerFrame: 0.2)
        node.run(SKAction.repeatForever(animation))
    }
    
    open override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            let touchedNode = atPoint(location)
            if touchedNode.name == "amy" {
                if myelin{
                    myelin = false
                    noMyelinNeuron.isHidden = false
                    myelinNeuron.isHidden = true
                    run(clickSoundEffect)
                } else {
                    myelin = true
                    noMyelinNeuron.isHidden = true
                    myelinNeuron.isHidden = false
                    run(clickSoundEffect)
                }
                
            }
        }
    }
}








