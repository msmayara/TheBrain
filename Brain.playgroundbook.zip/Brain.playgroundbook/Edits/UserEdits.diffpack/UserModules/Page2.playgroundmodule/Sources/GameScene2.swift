import SpriteKit

open class GameScene2: SKScene {
    
    open var background = SKSpriteNode(imageNamed: "backgroundPage2")
    open var brainAreas: SKSpriteNode!
    open var result: SKSpriteNode!
    open var frontalButton = SKSpriteNode(imageNamed: "frontalButton")
    open var parietalButton = SKSpriteNode(imageNamed: "parietalButton")
    open var temporalButton = SKSpriteNode(imageNamed: "temporalButton")
    open var occipitalButton = SKSpriteNode(imageNamed: "occipitalButton")
    open var cerebellumButton = SKSpriteNode(imageNamed: "cerebellumButton")
    open var brainstemButton = SKSpriteNode(imageNamed: "brainstemButton")
    
    
    
    var color: UIColor = .clear
    
    // Sound 
    let clickSoundEffect = SKAction.playSoundFileNamed("click.mp3", waitForCompletion: false)
    
    open override func sceneDidLoad(){
        //self.backgroundColor =  colorLiteral(red: 0.5998241305, green: 0.1623607874, blue: 0.7411823869, alpha: 1.0)
    }
    
    open override func didMove(to view: SKView) {
        self.size = view.frame.size
        
        // Add background
        background.name = "background"
        background.zPosition = 0
        background.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
        addChild(background)
        
        addBrain()
        addButtons()
    }
    
    open func createButton(node: SKSpriteNode, name: String){
        let buttonDimension = frame.width/8
        node.anchorPoint = CGPoint(x: 0, y: 0)
        node.name = name
        node.position = CGPoint(x: frame.midX/2, y: frame.midY/2)
        node.size = CGSize(width: buttonDimension, height: buttonDimension)
        addChild(node)
    }
    open func addButtons(){
        createButton(node: frontalButton, name: "frontalButton")
        createButton(node: parietalButton, name: "parietalButton")
        createButton(node: temporalButton, name: "temporalButton")
        createButton(node: occipitalButton, name: "occipitalButton")
        createButton(node: cerebellumButton, name: "cerebellumButton")
        createButton(node: brainstemButton, name: "brainstemButton")
        updateButtonsPositions()
    }
    
    open func updateButtonsPositions(){
        let buttonDimension = frame.width/8
        let distance = (frame.size.width - (6 * buttonDimension))/7
        let yPos: CGFloat = frame.midY * 1.6
        frontalButton.position = CGPoint(x: distance, y: yPos)
        parietalButton.position = CGPoint(x: 2 * distance + buttonDimension, y: yPos)
        temporalButton.position = CGPoint(x: 3 * distance + 2 * buttonDimension, y: yPos)
        occipitalButton.position = CGPoint(x: 4 * distance + 3 * buttonDimension, y: yPos)
        cerebellumButton.position = CGPoint(x: 5 * distance + 4 * buttonDimension, y: yPos)
        brainstemButton.position = CGPoint(x: 6 * distance + 5 * buttonDimension, y: yPos)
    }
    
    
    
    open func addBrain(){
        let brainTexture = SKTexture(imageNamed: "brainAreas")
        brainAreas = SKSpriteNode(texture: brainTexture)
        brainAreas.setScale(0.8)
        brainAreas.name = "brain"
        brainAreas.position = CGPoint(x: frame.midX, y:  frame.midY )
        addChild(brainAreas)
        
        let resultTexture = SKTexture(imageNamed: "result")
        result = SKSpriteNode(texture: resultTexture)
        result.name = "result"
        result.position = CGPoint(x: frame.midX, y:  frame.midY*0.3)
        addChild(result)
        
    }
    
    open override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            let touchedNode = atPoint(location)
            if touchedNode.name == "frontalButton" {
                brainAreas.texture = SKTexture(imageNamed: "frontalLobe")
                result.texture = SKTexture(imageNamed: "resultFrontalLobe")
                run(clickSoundEffect)
            } else if touchedNode.name == "parietalButton" {
                brainAreas.texture = SKTexture(imageNamed: "parietalLobe")
                result.texture = SKTexture(imageNamed: "resultParietalLobe")
                run(clickSoundEffect)
            } else if touchedNode.name == "temporalButton" {
                brainAreas.texture = SKTexture(imageNamed: "temporalLobe")
                result.texture = SKTexture(imageNamed: "resultTemporalLobe")
                run(clickSoundEffect)
            } else if touchedNode.name == "occipitalButton" {
                brainAreas.texture = SKTexture(imageNamed: "occipitalLobe")
                result.texture = SKTexture(imageNamed: "resultOccipitalLobe")
                run(clickSoundEffect)
            } else if touchedNode.name == "cerebellumButton" {
                brainAreas.texture = SKTexture(imageNamed: "cerebellum")
                result.texture = SKTexture(imageNamed: "resultCerebellum")
                run(clickSoundEffect)
            } else if touchedNode.name == "brainstemButton"  {
                brainAreas.texture = SKTexture(imageNamed: "brainstem")
                result.texture = SKTexture(imageNamed: "resultBrainstem")
                run(clickSoundEffect)
            }
        }
    }
}


