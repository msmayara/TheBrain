/*:
 We've seen that the brain is formed by a complex network of cells. Now, let's look into the bigger picture!  😄
 
 # The main areas of the brain
 The brain has three main parts: the cerebrum, the cerebellum and the brainstem. Each part is responsible for different tasks, but ultimately, all of the areas of the brain interact with one another to provide the foundation for our thoughts and behaviors.
 
 ## Cerebrum
 This the largest part of the brain. It control's the brain's higher functions, such as reasoning, emotions and [fine motor movements](glossary://fineMotorMovements).
 The cortex, which is the external and wrinkly surface, is divided into four main lobes:
 
 ### Frontal lobe
 The frontal lobe, located just behind your forehead, is the largest lobe of them all. This lobe is one of the major things that makes the human brain unique as it is important for a lot of [higher level cognitive abilities](glossary://higherLevelCognitiveAbilities). The frontal lobe has a region called **motor cortex**, which controls voluntary movements and sends messages from the brain out to the body like _"Pet that cat"_.
 
 ### Parietal lobe
 Located above and behind of the frontal lobe, we have the parietal lobe. This lobe is the key to processing information sensory from your body, such as your sense of touch. Your **somatosensory cortex**, located right behind the motor cortex, processes incoming sensations, like _"Oooh, that kitten is soft!_"
 
 ### Temporal lobe
 The temporal lobe, located above your ears, contais the **primary auditory cortex**, important for our ability to hear and process sound, including speech comprehension. The temporal lobe is also important for visual processing, like recognizing faces and objects.
 
 ### Occipital lobe
 At the back of the brain, there's the occipital lobe, which is the smallest of the lobes, but it is really important! The occipital lobe receives information related to sight and it is responsible for visual processing, such as images of objects and patterns, motion tracking, perceiving color and mapping space.
 
 ## Cerebellum
 The cerebellum, or "little brain", is located behind the cerebrum and it's very important for movement control, such as coordination, posture, and balance. This structure also plays a big role in [proprioception](glossary://proprioception).
 
 ## Brainstem
Located underneath the cerebellum, the brainstem is a narrow structure that regulates your heart rate, breathing, sleep and eating. All of the information transmitted between your body and your brain has to pass through this region.
 
 - callout(Experiment):
    - Tap "Run My Code" to learn about each part of the brain and explore them by taping on the actions to see which area is responsible for it
    - Make sure to have the sound on
 
 Besides being pretty awesome, your brain is a very important organ, that takes care of a lot of your body's functions. But how can **you** take care of your brain? 🤔 Check it out on the [**next page**](@next)!
*/

//#-hidden-code

import PlaygroundSupport

PlaygroundPage.current.setLiveView(GameViewController2())
//#-end-hidden-code


