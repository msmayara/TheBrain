/*:
Thankfully, scientists have found ways to improve brain health. Here's what they say we can do keep our brain healthy.
 
 # How to keep your brain healthy
 
 ## Eat healthy nutritious food 🍎
 Your brain needs energy to function properly. Eating healthy diverse food is an excellent way to provide energy and nutrients for your brain to stay healthy.
Foods like fruits, vegetables and nuts help your brain stay strong.
 
 ## Exercise 🏃
 Physical exercise is not only good for your health in general. It has an immediate positive effect on your mood and your focus, and it can also increase the size of your hippocampus, a part of your brain responsible for making memories. Scientists discovered that exercise generates a chemical called [BNDF](glossary://bndf), which encourages the growth of neural connections and new brain cells.
 
 ## Sleep 😴
 During sleep, your body balances and regulates its vital systems. Sleep is crucial for your brain's health, as it is during sleep that your brain repairs itself and processes all of the day's thinking. But that's not all: a good night of sleep can also help you remember things. During sleep, your brain consolidates new memories, that help you remember what you learn!
 
 ## Learn new things 💭
 The process of learning alters the structure of our brain at the cellular level. Due to [neuroplasticity](glossary://neuroplasticity), learning new things helps your brain to create new connections between its neurons.
 
 
 # Now that we've talked about our wonderful Brain, let's play a game!
 ![Play](play.png)
 The ideas represent the things you can do for your brain's health, such as learning new things, eating healthy food, sleeping, and exercising. Sometimes, you'll catch some not so good ideas, and that's okay too. Try to catch as many good ideas as you can!
 
 - callout(How to play):
    - Tap the brain to move him up and down and try to catch good ideas
    - Make sure to have the sound on
    - Tap "Run My Code" and have fun!
*/

//#-hidden-code

import PlaygroundSupport

PlaygroundPage.current.setLiveView(GameViewController3())
//#-end-hidden-code
