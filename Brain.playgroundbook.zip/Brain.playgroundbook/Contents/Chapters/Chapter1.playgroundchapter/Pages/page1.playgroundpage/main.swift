/*:

 ![Amy](amy.png)
 
 Your brain is a fantastic organ located inside your head that controls every single thing you do. The brain's complex network of cells are responsible for what define us as humans: our thoughts, memory, feelings and our experience of the world. Without the brain, we could not breathe, play, learn or remember.
 
 But to understand how our brains work, we first have to understand a little bit about the neuron.
 
 # The neuron
 The building blocks of the brain are cells called neurons. Neurons come in a variety of shapes and sizes, but in general, they have most of the same parts, as you can see in the picture below.
 
 ![Neuron parts](neuronParts.png)
 
 Scientists estimate that there are up to **86 billion neurons** in your brain. Those neurons can each form more than a thousand connections with other neurons, forming up to **100 trillion** connections!
 
 # Glia
 Although neurons are the most well known cells in our brains, there also other cell types in our nervous system, such as glia. These cells support neurons and can influence the way they communicate and grow. They also produce **myelin**, a substance that surrounds the neuron's axons and improve the communication between neurons.
 
 # The synapse
 Neurons communicate with each other transmitting signals across it's length. The communication point between two neurons is called synapse.
 
 Every neuron has so many synapses that it receives input from hundreds or thousands of other cells. That's a lot of communication going on in your brain!
 
 The neuron receives signals via its dendrites. If the signal is large enough, it triggers an [action potential](glossary://actionPotential) that transmittes the electric signal through the neuron length down its axon.
 
 # Myelin
 Axons can be very long, which means that the distance the signal travels can also get quite long. The axon can also have myelin around it, which acts as insulation and allows the signal to travel faster.
 
 Myelinated neurons can transmit a signal at speeds as high as 100 metres per second – **as fast as a Formula One racing car**! If the myelin sheath surrounding neurons is damaged or destroyed, transmission of nerve impulses is slowed or blocked.
 
 Myelin is essential for our movements, sensations and learning, as demonstrated by the consequences of disorders that affect it.
 
 - callout(Experiment):
    - Tap "Run My Code" to see how the propagation of the action potential occurs in a neuron with myelin
    - To see how the propagation of an impulse happens in a neuron without myelin, tap the button
    - Make sure to have the sound on
 
 It's pretty amazing to see that neurons connect with neurons from other areas to form the network that controls all your thoughts, feelings and actions. When you're ready to learn more about the brain's functions, let's go to the [**next page**](@next)!
*/

//#-hidden-code

import PlaygroundSupport

PlaygroundPage.current.setLiveView(GameViewController1())
//#-end-hidden-code
