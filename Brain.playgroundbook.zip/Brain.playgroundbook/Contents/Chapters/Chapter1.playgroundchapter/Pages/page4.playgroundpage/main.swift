/*:
![Thanks](thanks.png)
 
 # Credits
 
 Sounds from [Zapsplat.com](http://zapsplat.com/)
 
 Background music from [Starry Attic](https://www.youtube.com/watch?v=jFVguCEVAUs)

 Icons made by Freepik and dDara from [www.flaticon.com](http://www.flaticon.com/)
 
 # References
 
 [The neuron and nervous system](https://www.khanacademy.org/science/biology/human-biology#neuron-nervous-system)
 
 [The Neuron](https://www.brainfacts.org/brain-anatomy-and-function/anatomy/2012/the-neuron)
 
 [The importance of myelin](https://www.ms-society.ie/sites/default/files/2019-05/what%20is%20ms%20importance_myelin.pdf)
 
 [Anatomy of the Brain](https://www.hopkinsmedicine.org/health/conditions-and-diseases/anatomy-of-the-brain)
 
 [Teaching with the Brain in Mind](http://www.ascd.org/publications/books/104013/chapters/Meet-Your-Amazing-Brain.aspx)
 
 [5 tips to keep your brain healthy](https://www.mayoclinichealthsystem.org/hometown-health/speaking-of-health/5-tips-to-keep-your-brain-healthy)
 
 [Train your brain](https://www.health.harvard.edu/mind-and-mood/train-your-brain)
 
 [How the brain takes care of itself](https://www.ted.com/playlists/440/how_the_brain_takes_care_of_it)
 

*/

//#-hidden-code

import PlaygroundSupport

PlaygroundPage.current.setLiveView(GameViewController())
//#-end-hidden-code


